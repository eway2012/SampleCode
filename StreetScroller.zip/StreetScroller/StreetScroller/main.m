//
//  main.m
//  StreetScroller
//
//  Created by Eliza Block on 6/5/11.
//  Copyright 2011 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "StreetScrollerAppDelegate.h"

int main(int argc, char *argv[])
{
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([StreetScrollerAppDelegate class]));
    }
    return retVal;
}
