
#import "GesturesView.h"

@implementation GesturesView

@synthesize gestureRecognizers;

@end
